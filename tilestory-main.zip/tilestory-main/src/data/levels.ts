import { LevelConfig, BoardShapeType, BoardTile } from '../types/game';

export interface BoardCoord {
  r: number;
  c: number;
  l: number; // Layer: 0 = foundation, 1 = middle tier, 2 = summit tier, 3 = apex
}

// Multi-layer Mahjong Tower Coordinate Patterns (Deep stacking up to 6 layers: l: 0..5)
export interface BoardPillar {
  r: number;
  c: number;
  maxL: number;
}

export const SHAPE_PILLARS: Record<BoardShapeType, BoardPillar[]> = {
  pyramid: [],
  clover: [
    // 4 Core pillars (up to 6 layers deep)
    { r: 1.5, c: 2.0, maxL: 5 },
    { r: 1.5, c: 3.0, maxL: 5 },
    { r: 2.5, c: 2.0, maxL: 5 },
    { r: 2.5, c: 3.0, maxL: 5 },
    // 4 Mid-tier petals (up to 4 layers)
    { r: 0.5, c: 2.5, maxL: 3 },
    { r: 3.5, c: 2.5, maxL: 3 },
    { r: 2.0, c: 1.0, maxL: 3 },
    { r: 2.0, c: 4.0, maxL: 3 },
    // Outer perimeter accents (1-2 layers)
    { r: 0.5, c: 1.5, maxL: 1 },
    { r: 0.5, c: 3.5, maxL: 1 },
    { r: 3.5, c: 1.5, maxL: 1 },
    { r: 3.5, c: 3.5, maxL: 1 },
    { r: 4.5, c: 2.5, maxL: 1 }
  ],
  flower: [
    // Central blossom pillar (up to 6 layers)
    { r: 2.0, c: 2.5, maxL: 5 },
    { r: 1.5, c: 2.0, maxL: 4 },
    { r: 1.5, c: 3.0, maxL: 4 },
    { r: 2.5, c: 2.0, maxL: 4 },
    { r: 2.5, c: 3.0, maxL: 4 },
    // Surrounding petals (up to 3 layers)
    { r: 0.5, c: 2.5, maxL: 2 },
    { r: 2.0, c: 1.0, maxL: 2 },
    { r: 2.0, c: 4.0, maxL: 2 },
    { r: 3.5, c: 2.5, maxL: 2 },
    // Petal edges & stem
    { r: 1.0, c: 1.0, maxL: 1 },
    { r: 1.0, c: 4.0, maxL: 1 },
    { r: 3.0, c: 1.0, maxL: 1 },
    { r: 3.0, c: 4.0, maxL: 1 },
    { r: 4.5, c: 2.5, maxL: 1 }
  ],
  heart: [
    // Deep core heart gems (up to 6 layers)
    { r: 2.0, c: 2.5, maxL: 5 },
    { r: 1.5, c: 2.0, maxL: 4 },
    { r: 1.5, c: 3.0, maxL: 4 },
    { r: 2.5, c: 2.5, maxL: 4 },
    // Inner wings (up to 3 layers)
    { r: 1.0, c: 1.5, maxL: 3 },
    { r: 1.0, c: 3.5, maxL: 3 },
    { r: 3.0, c: 2.5, maxL: 2 },
    // Outer wings & tip
    { r: 0.5, c: 1.0, maxL: 1 },
    { r: 0.5, c: 4.0, maxL: 1 },
    { r: 2.0, c: 0.5, maxL: 1 },
    { r: 2.0, c: 4.5, maxL: 1 },
    { r: 4.0, c: 2.5, maxL: 1 }
  ],
  island: [
    // Mountain peaks (up to 6 layers)
    { r: 2.0, c: 2.5, maxL: 5 },
    { r: 2.0, c: 1.5, maxL: 4 },
    { r: 2.0, c: 3.5, maxL: 4 },
    // Plateau (up to 3 layers)
    { r: 1.0, c: 2.0, maxL: 3 },
    { r: 1.0, c: 3.0, maxL: 3 },
    { r: 3.0, c: 2.0, maxL: 2 },
    { r: 3.0, c: 3.0, maxL: 2 },
    // Beach & lagoon shore
    { r: 0.5, c: 1.0, maxL: 1 },
    { r: 0.5, c: 4.0, maxL: 1 },
    { r: 3.5, c: 1.0, maxL: 1 },
    { r: 3.5, c: 4.0, maxL: 1 }
  ],
  cloud: [
    // Central fluffy sun crest (up to 6 layers)
    { r: 1.5, c: 2.5, maxL: 5 },
    { r: 2.0, c: 2.0, maxL: 4 },
    { r: 2.0, c: 3.0, maxL: 4 },
    // Billow cheeks (up to 3 layers)
    { r: 2.0, c: 1.0, maxL: 3 },
    { r: 2.0, c: 4.0, maxL: 3 },
    { r: 1.0, c: 2.0, maxL: 2 },
    { r: 1.0, c: 3.0, maxL: 2 },
    // Perimeter puffs
    { r: 2.5, c: 1.5, maxL: 1 },
    { r: 2.5, c: 3.5, maxL: 1 },
    { r: 1.5, c: 0.5, maxL: 1 },
    { r: 1.5, c: 4.5, maxL: 1 }
  ],
  tree: [
    // Towering trunk & canopy crown (up to 6 layers)
    { r: 1.5, c: 2.5, maxL: 5 },
    { r: 2.5, c: 2.5, maxL: 5 },
    { r: 1.5, c: 1.5, maxL: 4 },
    { r: 1.5, c: 3.5, maxL: 4 },
    // Mid boughs (up to 3 layers)
    { r: 0.5, c: 2.5, maxL: 3 },
    { r: 2.5, c: 1.5, maxL: 2 },
    { r: 2.5, c: 3.5, maxL: 2 },
    // Trunk base & ground skirt
    { r: 3.5, c: 2.5, maxL: 1 },
    { r: 4.5, c: 2.5, maxL: 1 },
    { r: 0.5, c: 1.5, maxL: 1 },
    { r: 0.5, c: 3.5, maxL: 1 }
  ],
  butterfly: [
    // Thorax & head pinnacle (up to 6 layers)
    { r: 2.0, c: 2.5, maxL: 5 },
    { r: 1.0, c: 2.5, maxL: 4 },
    { r: 3.0, c: 2.5, maxL: 4 },
    // Inner wings (up to 3 layers)
    { r: 1.5, c: 1.5, maxL: 3 },
    { r: 1.5, c: 3.5, maxL: 3 },
    { r: 2.5, c: 1.5, maxL: 3 },
    { r: 2.5, c: 3.5, maxL: 3 },
    // Outer wing tips
    { r: 0.5, c: 0.5, maxL: 1 },
    { r: 0.5, c: 4.5, maxL: 1 },
    { r: 3.5, c: 0.5, maxL: 1 },
    { r: 3.5, c: 4.5, maxL: 1 }
  ],
  spiral: [
    // Center vortex (up to 6 layers)
    { r: 2.0, c: 2.5, maxL: 5 },
    { r: 1.5, c: 2.5, maxL: 4 },
    { r: 2.5, c: 2.5, maxL: 4 },
    // Spiral stair
    { r: 1.5, c: 1.5, maxL: 3 },
    { r: 2.5, c: 3.5, maxL: 3 },
    { r: 3.0, c: 2.0, maxL: 2 },
    { r: 1.0, c: 3.0, maxL: 2 },
    // Outer swirl
    { r: 0.5, c: 1.0, maxL: 1 },
    { r: 3.5, c: 4.0, maxL: 1 },
    { r: 0.5, c: 4.0, maxL: 1 },
    { r: 3.5, c: 1.0, maxL: 1 }
  ],
  house: [
    // Roof ridge & chimney spire (up to 6 layers)
    { r: 1.5, c: 2.5, maxL: 5 },
    { r: 2.5, c: 2.5, maxL: 5 },
    { r: 1.5, c: 1.5, maxL: 4 },
    { r: 1.5, c: 3.5, maxL: 4 },
    // Facade & windows (up to 3 layers)
    { r: 2.5, c: 1.5, maxL: 3 },
    { r: 2.5, c: 3.5, maxL: 3 },
    { r: 0.5, c: 2.5, maxL: 2 },
    // Porch & garden yard
    { r: 3.5, c: 1.5, maxL: 1 },
    { r: 3.5, c: 2.5, maxL: 1 },
    { r: 3.5, c: 3.5, maxL: 1 }
  ]
};

// Generate full BoardCoord[] flat patterns from SHAPE_PILLARS for compatibility
export const BOARD_PATTERNS: Record<BoardShapeType, BoardCoord[]> = Object.entries(SHAPE_PILLARS).reduce(
  (acc, [shape, pillars]) => {
    const coords: BoardCoord[] = [];
    pillars.forEach((p) => {
      for (let l = 0; l <= p.maxL; l++) {
        coords.push({ r: p.r, c: p.c, l });
      }
    });
    acc[shape as BoardShapeType] = coords;
    return acc;
  },
  {} as Record<BoardShapeType, BoardCoord[]>
);

/**
 * Exact 4-Tier 3D Mahjong Pyramid requested by user:
 * - Layer 0 (Zemin): 48 tiles
 * - Layer 1 (Üzerinde): 27 tiles
 * - Layer 2 (Üzerinde): 15 tiles
 * - Layer 3 (En üstte): 6 tiles
 * Total = 96 figures (exact 32 triplets of 3 matching figures)
 */
export function getPyramidCoordinates(): BoardCoord[] {
  const coords: BoardCoord[] = [];

  // Layer 0: Ground (48 tiles: 6 rows x 8 columns)
  for (let r = 0; r < 6; r++) {
    for (let c = 0; c < 8; c++) {
      coords.push({ r, c, l: 0 });
    }
  }

  // Layer 1: Over Ground (27 tiles: centered on Layer 0)
  const l1Rows = [
    { r: 0.5, cols: [1.5, 2.5, 3.5, 4.5, 5.5] }, // 5 tiles
    { r: 1.5, cols: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0] }, // 6 tiles
    { r: 2.5, cols: [1.5, 2.5, 3.5, 4.5, 5.5] }, // 5 tiles
    { r: 3.5, cols: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0] }, // 6 tiles
    { r: 4.5, cols: [1.5, 2.5, 3.5, 4.5, 5.5] }, // 5 tiles
  ];
  for (const row of l1Rows) {
    for (const c of row.cols) {
      coords.push({ r: row.r, c, l: 1 });
    }
  }

  // Layer 2: Over Layer 1 (15 tiles: centered on Layer 1)
  const l2Rows = [1.5, 2.5, 3.5];
  const l2Cols = [1.5, 2.5, 3.5, 4.5, 5.5];
  for (const r of l2Rows) {
    for (const c of l2Cols) {
      coords.push({ r, c, l: 2 });
    }
  }

  // Layer 3: Top summit (6 tiles: centered at the peak)
  const l3Rows = [2.0, 3.0];
  const l3Cols = [2.5, 3.5, 4.5];
  for (const r of l3Rows) {
    for (const c of l3Cols) {
      coords.push({ r, c, l: 3 });
    }
  }

  return coords; // Exactly 48 + 27 + 15 + 6 = 96 coordinates
}

/**
 * Returns board coordinates for the level matching the 50/30/15/5 multi-tier pyramid
 */
export function getBoardCoordinatesForLevel(_shape: BoardShapeType, tileCount: number): BoardCoord[] {
  const pyramid = getPyramidCoordinates();
  if (tileCount >= 96) {
    return pyramid;
  }
  return pyramid.slice(0, tileCount);
}

/**
 * Evaluates whether each tile on the board is covered by another tile in a higher layer.
 * A tile is covered if another tile exists with layer > tile.layer and horizontal/vertical
 * distance < 0.92 grid units (meaning the upper tile physically rests upon it).
 */
export function computeCoveredTiles(tiles: BoardTile[]): BoardTile[] {
  return tiles.map((tileA) => {
    const layerA = tileA.layer ?? 0;

    const isCovered = tiles.some((tileB) => {
      if (tileB.instanceId === tileA.instanceId) return false;
      const layerB = tileB.layer ?? 0;
      if (layerB <= layerA) return false;

      // Check distance in row and col
      const dRow = Math.abs(tileB.row - tileA.row);
      const dCol = Math.abs(tileB.col - tileA.col);

      // Overlapping tiles
      return dRow < 0.92 && dCol < 0.92;
    });

    return {
      ...tileA,
      isCovered
    };
  });
}

function createPyramidLevel(
  id: number,
  nameEn: string,
  nameTr: string,
  tileTypes: string[],
  hintEn: string,
  hintTr: string,
  worldItemUnlock?: string,
  difficultyGrade?: number,
  movesOverride?: number
): LevelConfig {
  // Distribute exactly 96 tiles into triplets of 3 (32 triplets total)
  const typeCount = tileTypes.length;
  const tripletsPerType = Math.floor(32 / typeCount);
  const remainderTriplets = 32 % typeCount;

  const tiles = tileTypes.map((tileId, idx) => {
    const triplets = tripletsPerType + (idx < remainderTriplets ? 1 : 0);
    return {
      tileId,
      count: triplets * 3
    };
  });

  const grade = difficultyGrade ?? (id <= 3 ? id : id + 5);
  const moves = movesOverride ?? (id === 1 ? 120 : id === 2 ? 115 : id === 3 ? 112 : Math.max(96, 110 - (id - 3) * 2));

  return {
    id,
    name: { en: nameEn, tr: nameTr },
    boardShape: 'pyramid',
    moves,
    difficulty: grade <= 3 ? 'easy' : grade <= 9 ? 'medium' : 'hard',
    difficultyGrade: grade,
    tutorialHint: { en: hintEn, tr: hintTr },
    tiles,
    objectives: [
      {
        type: 'merge_tile',
        targetTileId: 'all',
        targetCount: 96,
        currentCount: 0,
        label: { en: 'Clear All 96 Figures', tr: '96 Figürün Hepsini Temizle' }
      }
    ],
    rewards: {
      coins: 60 + id * 35,
      stars: 3,
      worldItemUnlock
    }
  };
}

export const LEVELS: LevelConfig[] = [
  createPyramidLevel(
    1,
    'Garden Pyramid',
    'Bahçe Piramidi',
    ['seed', 'water_drop', 'sun', 'leaf'],
    'Tap 3 matching figures to clear them and reveal the layers below!',
    '3 aynı figürü topla; 3 tane birikince tahtadan kalksın!',
    'patch_of_grass',
    1,
    120
  ),
  createPyramidLevel(
    2,
    'Morning Blooms',
    'Sabah Çiçekleri',
    ['flower', 'bee', 'leaf', 'sun', 'water_drop'],
    'Match figures in your basket. 3 identical figures vanish automatically!',
    'Aynı figürden 3 tane birikince tahtadan kendiliğinden kalkar!',
    'flower_pot_1',
    2,
    115
  ),
  createPyramidLevel(
    3,
    'Forest Whispers',
    'Orman Fısıltısı',
    ['tree', 'leaf', 'ladybug', 'seed', 'water_drop', 'sun'],
    'Match upper figures to gradually reveal deeper pyramid layers!',
    'Piramidin derin katmanlarını açmak için üstteki figürleri teker teker eşleştir!',
    'blooming_rose',
    3,
    112
  ),
  createPyramidLevel(
    4,
    'Crystal River',
    'Kristal Nehir',
    ['crystal', 'water_drop', 'cloud', 'rainbow', 'sun', 'flower', 'butterfly', 'bee', 'mushroom', 'ladybug', 'seed'],
    'Difficulty jumped by 6 grades after level 3! 11 distinct figure types challenge your 6 tray slots.',
    '3. oyundan sonra zorluk 6 derece birden arttı (Derece 9)! 11 farklı figür var, sepeti dikkatle planla!',
    'little_pond',
    9,
    105
  ),
  createPyramidLevel(
    5,
    'Sunlight Meadow',
    'Güneşli Çayır',
    ['sun', 'flower', 'bee', 'honey', 'sprout', 'leaf', 'seed', 'water_drop', 'crystal', 'butterfly', 'ladybug', 'mushroom'],
    'Grade 9: 12 distinct figure types! Don’t let your tray fill with 5 unmatched items.',
    'Zorluk Derecesi 9: 12 farklı figür! Sepette 5 farklı taş birikip kilitlenmeden 3’lüleri tamamla.',
    'sunflower_patch',
    9,
    102
  ),
  createPyramidLevel(
    6,
    'Bramble Grove',
    'Böğürtlen Korusu',
    ['seed', 'sprout', 'tree', 'mushroom', 'leaf', 'ladybug', 'water_drop', 'sun', 'berry', 'apple', 'caterpillar', 'flower', 'honey'],
    'Grade 10: 13 distinct types! Work your way through the summit pyramid layers.',
    'Zorluk Derecesi 10: 13 farklı figür! Piramidin zirvesinden başlayarak alt katmanların yolunu aç.',
    'young_oak_tree',
    10,
    100
  ),
  createPyramidLevel(
    7,
    'Rainbow Valley',
    'Gökkuşağı Vadisi',
    ['rainbow', 'cloud', 'crystal', 'butterfly', 'flower', 'sun', 'water_drop', 'bee', 'mushroom', 'ladybug', 'honeycomb', 'leaf', 'seed', 'tree'],
    'Grade 11: 14 distinct types! Every single tap must contribute to a planned triplet.',
    'Zorluk Derecesi 11: 14 farklı figür! Her dokunuşun planlı bir 3’lü eşleşmeye hizmet etmeli.',
    'bee_hotel',
    11,
    99
  ),
  createPyramidLevel(
    8,
    'Honey Sanctuary',
    'Bal Diyarı',
    ['honey', 'bee', 'flower', 'sun', 'leaf', 'seed', 'sprout', 'butterfly', 'ladybug', 'mushroom', 'crystal', 'rainbow', 'berry', 'apple', 'honeycomb'],
    'Grade 12: 15 distinct types! Grandmaster level challenge.',
    'Zorluk Derecesi 12: 15 farklı figür! Büyük Usta seviyesinde stratejik derinlik.',
    'cozy_beehive',
    12,
    98
  ),
  createPyramidLevel(
    9,
    'Enchanted Glade',
    'Büyülü Açıklık',
    ['crystal', 'rainbow', 'butterfly', 'tree', 'flower', 'water_drop', 'sun', 'mushroom', 'ladybug', 'bee', 'honey', 'sprout', 'seed', 'leaf', 'berry', 'apple'],
    'Grade 13: 16 distinct types! Exactly 2 triplets of each figure exist on the board.',
    'Zorluk Derecesi 13: 16 farklı figür! Her figürden yalnızca 2 üçlü bulunur, hata payı minimum.',
    'honey_stand',
    13,
    97
  ),
  createPyramidLevel(
    10,
    'Grand Garden Peak',
    'Büyük Bahçe Zirvesi',
    ['tree', 'honey', 'crystal', 'rainbow', 'butterfly', 'sun', 'flower', 'ladybug', 'mushroom', 'bee', 'sprout', 'seed', 'water_drop', 'leaf', 'berry', 'honeycomb'],
    'Grade 14: Apex Challenge! Exactly 96 moves for 96 figures. Flawless mastery required!',
    'Zorluk Derecesi 14: Nihai Zirve! 96 taşa karşı tam 96 hamle, sıfır hata ile şampiyonluk!',
    'cozy_cottage',
    14,
    96
  )
];
