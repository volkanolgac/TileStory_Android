import React from 'react';
import { motion } from 'motion/react';
import { sound } from '../../services/sound';
import { t } from '../../data/localization';

interface SplashScreenProps {
  onStart: () => void;
  language: 'en' | 'tr';
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStart, language }) => {
  return (
    <div
      onClick={() => {
        sound.playTap();
        sound.startAmbientMusic();
        onStart();
      }}
      className="relative w-full h-full flex flex-col items-center justify-between p-6 bg-gradient-to-b from-sky-200 via-emerald-100 to-amber-100 cursor-pointer select-none overflow-hidden"
    >
      {/* Gentle Floating Sky Elements */}
      <div className="absolute top-10 left-6 text-3xl opacity-80 animate-float-slow">☁️</div>
      <div className="absolute top-20 right-8 text-4xl opacity-70 animate-float-slow" style={{ animationDelay: '1.5s' }}>☁️</div>
      <div className="absolute top-8 right-12 text-5xl animate-pulse-glow">☀️</div>

      {/* Floating Animated Nature Motifs */}
      <motion.div
        animate={{ y: [0, -12, 0], rotate: [-2, 4, -2] }}
        transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
        className="mt-16 flex items-center justify-center gap-3"
      >
        <span className="text-4xl filter drop-shadow">🌱</span>
        <span className="text-5xl filter drop-shadow">🌸</span>
        <span className="text-4xl filter drop-shadow">🐝</span>
      </motion.div>

      {/* Center Hero Identity */}
      <div className="flex flex-col items-center text-center max-w-xs z-10">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 350, damping: 20 }}
          className="mb-2"
        >
          <div className="inline-block px-3 py-1 bg-amber-200/80 border border-amber-300 rounded-full text-amber-900 text-xs font-bold uppercase tracking-widest mb-3 shadow-xs">
            {t('gameSubtitle', language)}
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-800 tracking-tight leading-tight font-heading drop-shadow-sm">
            Tile Story
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-sm font-medium text-emerald-900/80 mt-2 px-2 leading-relaxed"
        >
          {t('tagline', language)}
        </motion.p>
      </div>

      {/* Tap to enter button */}
      <motion.div
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
        className="w-full max-w-xs mb-8 flex flex-col items-center gap-3"
      >
        <div className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-heading font-bold text-lg rounded-2xl shadow-lg border-2 border-emerald-300 flex items-center justify-center gap-2">
          <span>{t('play', language)}</span>
          <span className="text-xl">✨</span>
        </div>
        <span className="text-xs text-slate-500 font-semibold tracking-wide">
          {t('tapToContinue', language)}
        </span>
      </motion.div>
    </div>
  );
};
