import React from 'react';
import { motion } from 'motion/react';
import { Lock, Star, ChevronLeft } from 'lucide-react';
import { LEVELS } from '../../data/levels';
import { sound } from '../../services/sound';
import { t } from '../../data/localization';
import { PlayerProfile } from '../../types/game';

interface LevelMapScreenProps {
  profile: PlayerProfile;
  onSelectLevel: (levelId: number) => void;
  onBack: () => void;
  language: 'en' | 'tr';
}

export const LevelMapScreen: React.FC<LevelMapScreenProps> = ({
  profile,
  onSelectLevel,
  onBack,
  language
}) => {
  const levelIcons = ['🌱', '🌸', '🌿', '💧', '☀️', '🌳', '🐝', '🛖', '🍯', '🏡'];

  return (
    <div className="relative w-full h-full flex flex-col select-none overflow-hidden bg-gradient-to-b from-sky-200 via-emerald-100 to-amber-50">
      {/* Top Header */}
      <div className="px-4 py-3 flex items-center justify-between z-10 bg-white/70 backdrop-blur-xs border-b border-emerald-200 shadow-xs">
        <button
          id="level-map-back-btn"
          type="button"
          onClick={() => {
            sound.playTap();
            onBack();
          }}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold shadow-xs active:scale-95 transition-all"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>{t('back', language)}</span>
        </button>

        <h2 className="text-base font-bold text-slate-800 font-heading">
          {t('levelMap', language)}
        </h2>

        <div className="flex items-center gap-1 px-2.5 py-1 bg-amber-100 border border-amber-300 rounded-xl text-amber-900 text-xs font-bold">
          <span>⭐</span>
          <span>{profile.stars}</span>
        </div>
      </div>

      {/* Winding Garden Road Scrollable Area */}
      <div className="flex-1 overflow-y-auto p-4 relative no-scrollbar">
        {/* Subtle Path Guide Line */}
        <div className="flex flex-col items-center gap-8 py-6 max-w-xs mx-auto relative">
          
          {LEVELS.map((level, index) => {
            const isCompleted = profile.highestCompletedLevel >= level.id;
            const isCurrent = profile.currentLevel === level.id;
            const isLocked = level.id > profile.highestCompletedLevel + 1;
            const starsEarned = profile.levelStars[level.id] || (isCompleted ? 3 : 0);
            const icon = levelIcons[(level.id - 1) % levelIcons.length];

            // Winding zigzag x offset calculation
            const xOffset = Math.sin((index * Math.PI) / 2.5) * 55;

            return (
              <div
                key={level.id}
                className="relative flex flex-col items-center"
                style={{ transform: `translateX(${xOffset}px)` }}
              >
                {/* Connecting Stepping Stones between levels */}
                {index < LEVELS.length - 1 && (
                  <div className="absolute top-16 -bottom-6 w-1 flex flex-col items-center justify-around pointer-events-none opacity-40">
                    <div className="w-2 h-2 rounded-full bg-emerald-700" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-700" />
                    <div className="w-2 h-2 rounded-full bg-emerald-700" />
                  </div>
                )}

                {/* Level Node Button */}
                <motion.button
                  id={`level-node-${level.id}`}
                  type="button"
                  whileHover={!isLocked ? { scale: 1.1 } : {}}
                  whileTap={!isLocked ? { scale: 0.95 } : {}}
                  animate={
                    isCurrent
                      ? {
                          scale: [1, 1.08, 1],
                          boxShadow: [
                            '0 0 0 0 rgba(245, 158, 11, 0.4)',
                            '0 0 0 12px rgba(245, 158, 11, 0)',
                            '0 0 0 0 rgba(245, 158, 11, 0.4)'
                          ]
                        }
                      : {}
                  }
                  transition={
                    isCurrent
                      ? { repeat: Infinity, duration: 1.8, ease: 'easeInOut' }
                      : { type: 'spring', stiffness: 400, damping: 25 }
                  }
                  onClick={() => {
                    if (isLocked) {
                      sound.playError();
                      return;
                    }
                    sound.playTap();
                    onSelectLevel(level.id);
                  }}
                  disabled={isLocked}
                  className={`relative w-16 h-16 rounded-3xl flex flex-col items-center justify-center border-3 transition-all ${
                    isCurrent
                      ? 'bg-gradient-to-b from-amber-300 to-amber-500 border-amber-200 text-amber-950 shadow-lg ring-4 ring-amber-400/50 cursor-pointer'
                      : isCompleted
                      ? 'bg-gradient-to-b from-emerald-400 to-teal-500 border-emerald-200 text-white shadow-md cursor-pointer'
                      : 'bg-slate-200/80 border-slate-300 text-slate-400 opacity-70 cursor-not-allowed shadow-inner'
                  }`}
                >
                  {/* Icon & Level Number */}
                  <span className="text-xl filter drop-shadow-xs leading-none">
                    {icon}
                  </span>
                  <span className="text-xs font-extrabold font-heading mt-0.5">
                    {level.id}
                  </span>

                  {/* Locked indicator overlay */}
                  {isLocked && (
                    <div className="absolute inset-0 bg-slate-900/30 rounded-3xl flex items-center justify-center">
                      <Lock className="w-5 h-5 text-white/90 filter drop-shadow" />
                    </div>
                  )}

                  {/* Milestone Badge for Level 5 and Level 10 */}
                  {(level.id === 5 || level.id === 10) && (
                    <div className="absolute -top-2 -right-2 bg-rose-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full shadow-xs border border-white">
                      {level.id === 10 ? '👑' : '⭐'}
                    </div>
                  )}
                </motion.button>

                {/* Level Title, Difficulty Grade, and Star Rating */}
                <div className="mt-1.5 flex flex-col items-center">
                  <span className="text-[11px] font-bold text-slate-800 font-heading">
                    {level.name[language]}
                  </span>
                  {level.difficultyGrade && (
                    <span
                      className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded-full border shadow-2xs mt-0.5 flex items-center gap-0.5 ${
                        level.difficultyGrade >= 7
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      }`}
                    >
                      <span>{level.difficultyGrade >= 7 ? '🔥' : '🌱'}</span>
                      <span>{t('difficultyGrade', language)} {level.difficultyGrade}</span>
                    </span>
                  )}
                  {isCompleted && (
                    <div className="flex gap-0.5 items-center mt-0.5">
                      {Array.from({ length: 3 }).map((_, sIdx) => (
                        <Star
                          key={sIdx}
                          className={`w-3 h-3 ${
                            sIdx < starsEarned
                              ? 'fill-amber-400 text-amber-500'
                              : 'fill-slate-300 text-slate-300'
                          }`}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
